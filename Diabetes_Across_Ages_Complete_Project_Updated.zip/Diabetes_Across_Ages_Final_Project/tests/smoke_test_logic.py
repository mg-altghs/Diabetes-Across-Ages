"""
Logic smoke test for app.py WITHOUT a browser.

It replaces `streamlit` and `plotly` with light stand-ins, then executes every dashboard page so that all
pandas / scikit-learn code paths run for real (data loading, filters, metrics, the live Logistic Regression
prediction) and every column name passed to a Plotly Express call is checked against its DataFrame.
It does NOT test visual rendering - for that, run `streamlit run app.py` and click through the pages.

Run from the project folder:   python tests/smoke_test_logic.py
"""
import sys, runpy, types
from pathlib import Path
from unittest.mock import MagicMock
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


class Ctx:
    def __init__(self, st): self._st = st
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, n): return getattr(self._st, n)


class FakeSt:
    def __init__(self):
        self.session_state = {}
        self.calls = []
        self.overrides = {}
        self.sidebar = Ctx(self)
        self.errors = []

    def _rec(self, name): self.calls.append(name)

    # decorators
    def cache_data(self, *a, **k):
        if len(a) == 1 and callable(a[0]) and not k: return a[0]
        return lambda f: f
    cache_resource = cache_data

    # layout
    def columns(self, spec, **k): return [Ctx(self) for _ in range(spec if isinstance(spec, int) else len(spec))]
    def tabs(self, names): return [Ctx(self) for _ in names]
    def expander(self, *a, **k): return Ctx(self)
    def form(self, *a, **k): return Ctx(self)
    def spinner(self, *a, **k): return Ctx(self)

    # widgets
    def radio(self, label, options, index=0, key=None, **k):
        if key and key in self.session_state: return self.session_state[key]
        return self.overrides.get(label, list(options)[index])
    def selectbox(self, label, options, index=0, **k): return self.overrides.get(label, list(options)[index])
    def multiselect(self, label, options, default=None, **k): return self.overrides.get(label, default or [])
    def slider(self, label, mn, mx, value=None, *a, **k): return self.overrides.get(label, value)
    def number_input(self, label, min_value=None, max_value=None, value=None, **k): return self.overrides.get(label, value)
    def button(self, label, **k): return label.startswith("Run reproducibility")
    def form_submit_button(self, *a, **k): return self.overrides.get("submit", True)

    # outputs
    def plotly_chart(self, fig, **k): self._rec("plotly_chart")
    def dataframe(self, df, **k): assert isinstance(df, pd.DataFrame); self._rec("dataframe")
    def error(self, *a, **k): self.errors.append(a)
    def __getattr__(self, n):
        if n.startswith("_"): raise AttributeError(n)
        return lambda *a, **k: self._rec(n)


COLUMN_ARGS = ["x", "y", "color", "names", "values", "text", "error_x"]


def px_stub(name):
    def f(df=None, *args, **kw):
        if isinstance(df, pd.DataFrame):
            for key in COLUMN_ARGS:
                v = kw.get(key)
                if isinstance(v, str):
                    assert v in df.columns, f"px.{name}: column '{v}' (arg {key}) not in {list(df.columns)}"
            for key in (kw.get("hover_data") or {}):
                assert key in df.columns, f"px.{name}: hover_data column '{key}' missing"
        return MagicMock()
    return f


def install_fakes(fake):
    st = types.ModuleType("streamlit")
    for n in dir(fake):
        if not n.startswith("_"): setattr(st, n, getattr(fake, n))
    st.session_state = fake.session_state
    st.__getattr__ = lambda n: getattr(fake, n)
    px = types.ModuleType("plotly.express")
    for n in ["bar", "line", "box", "pie", "histogram", "imshow", "scatter"]: setattr(px, n, px_stub(n))
    go = MagicMock()
    pl = types.ModuleType("plotly"); pl.express = px; pl.graph_objects = go
    sys.modules.update({"streamlit": st, "plotly": pl, "plotly.express": px, "plotly.graph_objects": go})


PAGES = ["Overview", "Diabetes Across Age Groups", "Machine Learning Explorer", "Model Performance",
         "Interactive ML Prediction", "Model Explainability", "Dataset & Methodology"]
SCENARIOS = [("Diabetes Across Age Groups", {"Age group": "Older adults 60+"}),
             ("Diabetes Across Age Groups", {"Age group": "Adults 18–59", "Sex": ["Female"]}),
             ("Diabetes Across Age Groups", {"Age range (80 = 80 and over)": (30, 50)})]
for choice in ["Sex", "Race/ethnicity", "Education", "Daily sitting time", "Income-to-poverty ratio"]:
    SCENARIOS.append(("Diabetes Across Age Groups", {"Factor to compare across age groups": choice}))
for m in ["Random Forest", "XGBoost"]:
    SCENARIOS.append(("Machine Learning Explorer", {"Model": m}))
for s in ["Adults 18–59", "Older adults 60+"]:
    SCENARIOS.append(("Model Explainability", {"Permutation importance subset (held-out test, ROC-AUC drop)": s}))
SCENARIOS.append(("Interactive ML Prediction", {"Race/ethnicity": 7, "Age (years; NHANES records 80 for ages 80+)": 19}))
SCENARIOS.append(("Interactive ML Prediction", {"submit": False}))


def run(page, overrides):
    fake = FakeSt(); fake.overrides = overrides; fake.session_state["page"] = page
    install_fakes(fake)
    runpy.run_path(str(ROOT / "app.py"), run_name="__main__")
    assert not fake.errors, fake.errors
    return fake


if __name__ == "__main__":
    n = 0
    for p in PAGES:
        f = run(p, {}); n += 1
        print(f"OK  {p:32s} charts={f.calls.count('plotly_chart'):2d} tables={f.calls.count('dataframe')}")
    for p, ov in SCENARIOS:
        run(p, ov); n += 1
        print(f"OK  {p:32s} scenario {ov}")
    print(f"\nAll {n} page runs completed without errors.")
