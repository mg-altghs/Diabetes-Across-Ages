# Public deployment guide (Streamlit Community Cloud)

The project is built as a Streamlit web application. It is interactive when run locally; a public URL requires deployment to a hosting provider. This package has not been deployed and no public URL is claimed.

1. Create a GitHub repository and upload the complete project folder contents (including `app.py`, `requirements.txt`, `.streamlit/config.toml`, `data/` and `results/`).
2. Confirm the repository is accessible to Streamlit Community Cloud. Public repositories are simplest for a student demonstration; check your institution's data/code-sharing rules first.
3. Sign in to Streamlit Community Cloud using GitHub and choose **Create app**.
4. Select the repository, branch, and `app.py` as the main file.
5. Deploy. Streamlit installs packages from `requirements.txt` and provides a public app URL.
6. Open the URL in a private/incognito browser window to verify that it works for viewers who are not logged in to your account.

The app reads static public NHANES files bundled in `data/`. Public hosting does not make the underlying survey data live. The interactive prediction form calculates output on submission; the source survey itself does not update automatically.

## Before sharing

- Test the deployed app on desktop and mobile.
- Confirm all charts and prediction form work.
- Do not add personal, patient-identifiable or confidential information.
- Keep the academic disclaimer visible.
