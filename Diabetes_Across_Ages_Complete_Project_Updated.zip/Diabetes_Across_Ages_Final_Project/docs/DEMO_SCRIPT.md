# Demonstration script (about 8 minutes live, plus questions)

**Before you start:** run `streamlit run app.py` once and open the app so it is already loaded. Keep the PowerPoint
(`presentation/`) open next to it. Fill in your name, roll number and guide on slide 1, and add screenshots to slide 12.

## 0. One-sentence opener (20 s)
"My project studies how diabetes-related patterns differ between adults aged 18-59 and older adults aged 60 and above in
NHANES 2021-2023 data, and builds an explainable classifier for self-reported diagnosed diabetes in adults."

## 1. Overview page (1 min)
- Point at the KPI cards: 11,933 participants, **7,876 eligible adults**, **1,073** reported diagnosis, **13.62%** sample proportion.
- Say: "These are unweighted sample proportions, not national prevalence."
- Say: "The classifier is adults-only. There is no child classifier."

## 2. Diabetes Across Age Groups (1.5 min)
- Show the age-band bar chart: the proportion rises from about 1.5% (18-29) to about 24% (70-79).
- Switch the **Age group** filter to "Older adults 60+", then back. Drag the age-range slider.
- Open the **BMI comparison** tab: proportion rises with BMI category in both groups, and is higher in older adults.
- Say: "These are associations in an unweighted sample, not causes."

## 3. Machine Learning Explorer (1 min)
- Walk the six steps: merge, 60/20/20 split, preprocessing fitted on train only, three models, select on validation, test once.
- Show validation ROC-AUC: Logistic Regression 0.7944, XGBoost 0.7904, Random Forest 0.7816.
- Say: "I chose by validation ROC-AUC, and set the threshold 0.64 by maximum validation F1. The differences are small, and the
  linear model is also the most interpretable."

## 4. Model Performance (1.5 min)
- Held-out **test** tab: accuracy 78.30%, recall 53.95%, specificity 82.15%, precision 32.31%, ROC-AUC 0.7883.
- Show the confusion matrix (1,118 / 243 / 99 / 116), the ROC curve and the PR curve.
- Click **Validation results** to show the validation and test results are kept separate.
- Click **Test results by age group**: 18-59 has ROC-AUC 0.824 (recall 33.85%, specificity 95.69%); 60+ has ROC-AUC 0.663
  (recall 62.67%, specificity 60.65%).
- Be honest: "Precision and recall are modest; accuracy alone is misleading with 13.6% positives."

## 5. Interactive ML Prediction (1.5 min) - the main demo
- Enter, for example: age 62, female, Non-Hispanic Black, high school graduate, income ratio 1.5, BMI 33, sedentary 480 min. Click **Run model prediction**.
- Explain the output: classification (positive/negative at threshold 0.64), the model score, the gauge, and the bar chart of
  what pushed the score up or down.
- Change age to 28 and BMI to 22 and run again to show the score falls.
- Open **"Show exactly what the pipeline received"** to prove the input goes through the real trained pipeline.
- Say: "This is an academic demonstration, not a diagnosis or clinical risk score."

## 6. Model Explainability (45 s)
- SHAP: age 0.924, BMI 0.375, education 0.334 ... Permutation importance agrees (age, then BMI).
- Say: "Importance describes the model, not causes."

## 7. Dataset & Methodology (45 s)
- Show the missing-values table and the Limitations tab.
- Click **Reproducibility check**: the live pipeline matches the saved results exactly.

## Likely questions and safe answers
- **Why Logistic Regression?** Highest validation ROC-AUC, simplest and most interpretable; margin over XGBoost is small (0.7944 vs 0.7904).
- **Why threshold 0.64?** It maximised F1 on the validation set. It is not a clinical threshold; a different cost trade-off would change it.
- **Why is performance worse for 60+?** Same fixed threshold; different sample proportion (22.19% vs 7.22%); and age, the strongest
  feature, separates cases less within the older group (permutation importance 0.008 vs 0.153). Subgroup results are descriptive; 18-59 has only 65 test cases.
- **Is 13.62% the diabetes prevalence?** No. It is an unweighted analytic-sample proportion; NHANES survey weights were not used.
- **Why not use HbA1c?** It is used to diagnose diabetes, so it would leak the outcome.
- **Does it predict who will get diabetes?** No. It reproduces the self-reported diagnosis label; it is not a future-onset model.
- **What about undiagnosed diabetes?** Self-report misses it; this is a stated limitation.
- **Is there anything in the preprocessing you would improve?** Yes (be upfront): race/ethnicity code 7 ("Other race, including
  multi-racial", 529 people) is recoded to missing and imputed by the original pipeline. The dashboard reproduces this so it
  matches your saved results. Fixing it means editing one line in the pipeline and re-running it; metrics will then change slightly,
  so re-check every number in the slides if you do.
