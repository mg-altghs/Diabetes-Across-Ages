# Methodology and data dictionary

## Source files

| File | Purpose | Variables used |
|---|---|---|
| `DEMO_L.xpt` | Demographics and survey design | `SEQN`, `RIDAGEYR`, `RIAGENDR`, `RIDRETH3`, `DMDEDUC2`, `INDFMPIR` |
| `DIQ_L.xpt` | Diabetes questionnaire | `SEQN`, `DIQ010` |
| `BMX_L.xpt` | Body measures | `SEQN`, `BMXBMI`, `BMDBMIC` |
| `PAQ_L.xpt` | Physical activity / sedentary behaviour | `SEQN`, `PAD680` |

All files are from NHANES August 2021–August 2023. Participants are merged by `SEQN` using one-to-one joins.

## Adult target

`DIQ010=1` is positive (self-reported Yes to having been told by a health professional that the participant has diabetes); `DIQ010=2` is negative. Other codes and missing responses are excluded from the supervised classifier. This target is not future diabetes onset and does not identify undiagnosed diabetes.

## Predictor definitions

- `RIDAGEYR`: age in years.
- `RIAGENDR`: sex code.
- `RIDRETH3`: race/ethnicity category.
- `DMDEDUC2`: education category for adults.
- `INDFMPIR`: family income-to-poverty ratio.
- `BMXBMI`: body mass index (kg/m²).
- `PAD680`: self-reported time spent sitting on a typical day (minutes).

HbA1c (`LBXGH`) is not included as a predictor because it is directly related to diabetes status and could cause diagnostic leakage. Survey weights and design fields are not predictors.

## Missing-value handling

Special nonresponse values are converted to missing values where applicable. Numeric predictors use median imputation and standard scaling; categorical predictors use most-frequent imputation and one-hot encoding. The transformations are fitted within the training pipeline.

## Validation design

The eligible adult sample is split using stratified sampling: 60% train, 20% validation, 20% held-out test. Random states are 42 and 43. Logistic Regression, Random Forest and XGBoost are compared. The highest validation ROC-AUC determines the selected model; the decision threshold is selected by maximising validation F1. The test set is used once for final reporting.

## Child analysis

Participants younger than 18 are described using `BMDBMIC` BMI-for-age categories: 1 underweight, 2 healthy weight, 3 overweight, 4 obesity. This descriptive analysis is not a diabetes diagnosis or prevalence estimate. Records without a BMI-for-age category are excluded from category proportions.

## Interpretation safeguards

All analytic proportions and model metrics in this project are unweighted. NHANES strata, PSU and sampling weights are not incorporated in estimates or model fitting. Consequently, results must not be presented as nationally representative estimates. The study uses one cycle and has no external validation. Feature importance is not causal evidence. The application is not a clinical tool.
